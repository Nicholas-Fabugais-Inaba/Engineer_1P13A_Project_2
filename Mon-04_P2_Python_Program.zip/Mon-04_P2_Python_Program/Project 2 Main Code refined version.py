import time
import sys
import random
sys.path.append('../')

from Common_Libraries.p2_lib import *

import os
from Common_Libraries.repeating_timer_lib import repeating_timer

def update_sim ():
    try:
        arm.ping()
    except Exception as error_update_sim:
        print (error_update_sim)

arm = qarm()

update_thread = repeating_timer(2, update_sim)
#==========================================

#global varibles
th = 0.5 
objects = [1,2,3,4,5,6]
pickup = [0.5,0.0,0.0]

def bin_location(id): #define new function bin_location
    if id == 1: #Red small
        return[-0.624,0.2592,0.385]#return xyz location
    elif id == 2: #Green small
        return[0.0,-0.6773,0.385]#return xyz location
    elif id == 3: #Blue small
        return[0.0,0.6773,0.385]#return xyz location
    elif id == 4: #Red Large
        return[-0.4519,0.1872,0.3093]#return xyz location
    elif id == 5: #Green Large
        return[0.0,-0.4891,0.3093]#return xyz location
    elif id == 6: #Blue Large
        return[0.0,0.4891,0.3093]#return xyz location
    else:
        arm.home()

def control_gripper():#define new function control_gripper (Arms used: that only use left arm if left arm < th grab or left arm > th open)
    while True:#infinite while loop
        if arm.emg_left() < th and arm.emg_right() == 0:#if left arm is smaller than th and right arm = 0 
            arm.control_gripper(55)#close gripper
            break#break loop
        elif arm.emg_left() > th and arm.emg_right() == 0:#if right arm is bigger than th and right arm = 0
            arm.control_gripper(-55)#open gripper
            break#break loop

def move_endeffector(location):#define new function move_endeffector (Arms used: only use right arm if right arm > th move to location xyz)
    while True:#infinite while loop
        if arm.emg_right() > th and arm.emg_left() == 0: #if right arm is bigger than th and left arm = 0
            arm.move_arm(location[0],location[1],location[2]) #move to location xyz
            break#breakloop

def autoclave_drawer(drawer_open,id):#define new function autoclave_drawer (Arms used: use both arms if they are all above th and equal)
        if drawer_open == True:#check if drawer_open is True(any drawer is oepn)
            arm.open_red_autoclave(False)#close all drawers
            arm.open_green_autoclave(False)
            arm.open_blue_autoclave(False)
            return False #return False and break loop
        else:#if drawer_open is False(Drawers are closed)
            while True:#infinite while loop
                if arm.emg_left() == arm.emg_right() and arm.emg_left() > th and arm.emg_right(): #if left and right arm are equal and they are both above th
                    if id == 4:#if id is 4(Large red)
                        arm.open_red_autoclave(True)#open red autoclave drawer
                    elif id == 5:#if id is 5(Large green)
                        arm.open_green_autoclave(True)#open green autoclave drawer
                    elif id == 6:#if id is 6(Large blue)
                        arm.open_blue_autoclave(True)#open blue autoclave drawer
                    return True#renturn True and break loop 
        
def main(): #define main function
    drawer_open = False #local varible that rest everytime execute the function

    time.sleep(0.5) #sleep for 0.5s 
    arm.home() #move arm back to home posistion
    id = random.choice(objects) #random choice from objects
    objects.remove(id) #remove id from objects ist
    arm.spawn_cage(id) #spawn mathced cage
    
    move_endeffector(pickup) #move to pickup location
    control_gripper() #call control gripper function
    time.sleep(0.75) #sleeps for 0.75s
    arm.move_arm(0.4064,0.0,0.4826) #move to home position(Gripper will still be closed)
    move_endeffector(bin_location(id)) #move to matched drop location
    time.sleep(1.5)#sleeps for 1.5s 
    
    if id > 3: #if id = 4 5 or 6(Large container)
        drawer_open = autoclave_drawer(drawer_open,id) #call drawer open function and saves return into drawer_open variable
        control_gripper()#call control gripper function
        time.sleep(1.5)#sleeps for 1.5s
        drawer_open = autoclave_drawer(drawer_open,id) #call drawer open function and saves return into drawer_open variable
    else: # if id = 12 or 3(Small container)
        control_gripper()#call control gripper function
        time.sleep(1) #sleeps for 1s
    
def continue_terminate(): #define new function continue_terminate
    for i in range(6): #loop that execute 6 times
        main() #call main function
    exit()#exit program

continue_terminate() #call continue_terminate function
