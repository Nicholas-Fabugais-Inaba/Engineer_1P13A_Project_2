import time
import sys
import random
sys.path.append('../')

from Common_Libraries.p2_lib import *

import os
from Common_Libraries.repeating_timer_lib import repeating_timer

def update_sim ():
    try:
        arm.ping()
    except Exception as error_update_sim:
        print (error_update_sim)

arm = qarm()

update_thread = repeating_timer(2, update_sim)
#==========================================

th = 0.5
objects = [1,2,3,4,5,6]
pickup = [0.5,0.0,0.0]

def bin_location(id):
    if id == 1: #Red small
        return[-0.624,0.2592,0.385]
    elif id == 2: #Green small
        return[0.0,-0.6773,0.385]
    elif id == 3: #Blue small
        return[0.0,0.6773,0.385]
    elif id == 4: #Red Large
        return[-0.4519,0.1872,0.3093]
    elif id == 5: #Green Large
        return[0.0,-0.4891,0.3093]
    elif id == 6: #Blue Large
        return[0.0,0.4891,0.3093]
    else:
        arm.home()

def control_gripper():
    while True:
        if arm.emg_left() < th and arm.emg_right() == 0:
            arm.control_gripper(55)
            break
        elif arm.emg_left() > th and arm.emg_right() == 0:
            arm.control_gripper(-55)
            break

def move_endeffector(location):
    while True:
        if arm.emg_right() > th and arm.emg_left() == 0: #move to XYZ location
            arm.move_arm(location[0],location[1],location[2])
            break

def autoclave_drawer(drawer_open,id):
        if drawer_open == True:
            arm.open_red_autoclave(False)
            arm.open_green_autoclave(False)
            arm.open_blue_autoclave(False)
            return False
        else:
            while True:
                if arm.emg_left() == arm.emg_right() and arm.emg_left() > th and arm.emg_right():
                    if id == 4:
                        arm.open_red_autoclave(True)
                        return True
                    elif id == 5:
                        arm.open_green_autoclave(True)
                        return True
                    elif id == 6:
                        arm.open_blue_autoclave(True)
                        return True
        
def main():
    drawer_open = False
    time.sleep(0.5)
    arm.home()
    id = random.choice(objects)
    objects.remove(id)
    arm.spawn_cage(id)
    
    move_endeffector(pickup)
    control_gripper()
    time.sleep(0.75)
    arm.move_arm(0.4064,0.0,0.4826)
    move_endeffector(bin_location(id))
    time.sleep(1.5)
    
    if id > 3:
        drawer_open = autoclave_drawer(drawer_open,id)
        control_gripper()
        time.sleep(1.5)
        drawer_open = autoclave_drawer(drawer_open,id)
    else:
        control_gripper()
        time.sleep(1)
    
def continue_terminate():
    for i in range(6):
        main()
    exit()

continue_terminate() 
